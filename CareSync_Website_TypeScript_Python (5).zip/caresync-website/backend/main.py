from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from datetime import datetime, timezone

app = FastAPI(title="CareSync API", version="0.1.0")

# Local development only. Restrict this to your deployed frontend domain in production.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class DemoEntry(BaseModel):
    role: str = "Hospital Administrator"

@app.get("/api/health")
def health():
    return {"status": "ok", "service": "CareSync API"}

@app.post("/api/demo-entry")
def demo_entry(payload: DemoEntry):
    # This is demo entry only, not real authentication.
    return {
        "ok": True,
        "role": payload.role,
        "message": "Welcome to the CareSync demo",
        "entered_at": datetime.now(timezone.utc).isoformat(),
    }

@app.get("/api/overview")
def overview():
    # Fictional demonstration values; no real patient information is used.
    return {
        "demo": True,
        "hospital": "CareSync Demo Hospital",
        "beds": {"total": 240, "occupied": 176, "available": 48, "blocked": 16},
        "waiting_patients": 12,
        "pending_discharges": 7,
        "delayed_lab_reports": 5,
        "staff_on_duty": 38,
        "alerts": [
            {
                "priority": "High",
                "title": "Discharge coordination needs review",
                "detail": "Three demo discharge records are waiting for final checks."
            },
            {
                "priority": "Medium",
                "title": "Diagnostic report delay",
                "detail": "Two demo lab reports are beyond the target turnaround time."
            },
            {
                "priority": "Low",
                "title": "Ward capacity available",
                "detail": "Review available beds before redirecting incoming patients."
            }
        ]
    }
