import { useEffect, useState } from "react";
import {
  Activity, ArrowDownRight, ArrowUpRight, BedDouble, Bell, CheckCircle2,
  ChevronRight, ClipboardList, Clock3, FlaskConical, HeartPulse, LayoutDashboard,
  LogOut, Menu, Moon, Search, Settings, ShieldCheck, Sparkles, Stethoscope,
  Users, X
} from "lucide-react";

type Overview = {
  demo: boolean;
  hospital: string;
  beds: { total: number; occupied: number; available: number; blocked: number };
  waiting_patients: number;
  pending_discharges: number;
  delayed_lab_reports: number;
  staff_on_duty: number;
  alerts: { priority: string; title: string; detail: string }[];
};

const fallbackOverview: Overview = {
  demo: true,
  hospital: "CareSync Demo Hospital",
  beds: { total: 240, occupied: 176, available: 48, blocked: 16 },
  waiting_patients: 12,
  pending_discharges: 7,
  delayed_lab_reports: 5,
  staff_on_duty: 38,
  alerts: [
    { priority: "High", title: "Discharge coordination needs review", detail: "Three demo discharge records are waiting for final checks." },
    { priority: "Medium", title: "Diagnostic report delay", detail: "Two demo lab reports are beyond the target turnaround time." },
    { priority: "Low", title: "Ward capacity available", detail: "Review available beds before redirecting incoming patients." }
  ]
};

type Screen = "login" | "dashboard";

export default function App() {
  const [screen, setScreen] = useState<Screen>("login");
  const [role, setRole] = useState("Hospital Administrator");
  const [overview, setOverview] = useState<Overview>(fallbackOverview);
  const [apiStatus, setApiStatus] = useState<"checking" | "online" | "offline">("checking");
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeNav, setActiveNav] = useState("Overview");
  const [notice, setNotice] = useState("");

  useEffect(() => {
    fetch("http://127.0.0.1:8000/api/overview")
      .then((r) => { if (!r.ok) throw new Error("API unavailable"); return r.json(); })
      .then((data: Overview) => { setOverview(data); setApiStatus("online"); })
      .catch(() => setApiStatus("offline"));
  }, []);

  async function enterDemo() {
    try {
      const response = await fetch("http://127.0.0.1:8000/api/demo-entry", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ role })
      });
      if (!response.ok) throw new Error("API unavailable");
      setApiStatus("online");
    } catch {
      setApiStatus("offline");
    }
    setScreen("dashboard");
  }

  function logout() {
    setScreen("login");
    setNotice("");
    setMenuOpen(false);
  }

  if (screen === "login") {
    return (
      <main className="login-screen">
        <div className="login-backdrop" />
        <header className="login-topbar">
          <Brand />
          <div className="secure-note"><ShieldCheck size={16} /> Designed for coordinated care</div>
        </header>
        <section className="login-content">
          <div className="hero-copy">
            <div className="eyebrow"><span className="live-dot" /> HOSPITAL OPERATIONS, IN SYNC</div>
            <h1>Better care starts<br />with <span>better coordination.</span></h1>
            <p>Bring beds, care teams, diagnostics and discharge workflows together in one calm, clear workspace.</p>
            <div className="hero-points">
              <span><CheckCircle2 size={17} /> One connected view</span>
              <span><CheckCircle2 size={17} /> Faster team decisions</span>
              <span><CheckCircle2 size={17} /> Clear operational signals</span>
            </div>
          </div>
          <div className="glass-login">
            <div className="login-icon"><HeartPulse size={25} /></div>
            <p className="small-label">WELCOME TO CARESYNC</p>
            <h2>Your hospital,<br />working as one.</h2>
            <p className="login-description">Enter the interactive demo workspace. No account details needed.</p>
            <label className="field-label" htmlFor="role">Choose demo role <span>optional</span></label>
            <div className="select-wrap">
              <select id="role" value={role} onChange={(e) => setRole(e.target.value)}>
                <option>Hospital Administrator</option>
                <option>Bed Management Staff</option>
                <option>Doctor</option>
                <option>Discharge Coordinator</option>
              </select>
              <ChevronRight size={17} />
            </div>
            <button className="primary-button" onClick={enterDemo}>
              Enter CareSync <ChevronRight size={18} />
            </button>
            <div className="no-account"><ShieldCheck size={15} /> Demo access — no username or password</div>
            <div className="login-divider"><span>BUILT FOR BETTER FLOW</span></div>
            <div className="login-mini-stats">
              <div><strong>24/7</strong><span>Operational view</span></div>
              <div><strong>1</strong><span>Connected workspace</span></div>
              <div><strong>∞</strong><span>Room to improve</span></div>
            </div>
          </div>
        </section>
        <footer className="login-footer"><span>© 2026 CareSync Demo</span><span>Fictional demonstration data · Not for clinical use</span></footer>
      </main>
    );
  }

  const occupancy = Math.round((overview.beds.occupied / overview.beds.total) * 100);
  const navItems = [
    { name: "Overview", icon: LayoutDashboard },
    { name: "Bed Management", icon: BedDouble },
    { name: "Appointments", icon: Clock3 },
    { name: "Diagnostics & Labs", icon: FlaskConical },
    { name: "Staff & Rosters", icon: Users },
    { name: "AI Insights", icon: Sparkles }
  ];

  return (
    <main className="app-shell">
      <aside className={`sidebar ${menuOpen ? "sidebar-open" : ""}`}>
        <div className="sidebar-brand"><Brand /></div>
        <div className="hospital-switcher">
          <div className="hospital-avatar"><HeartPulse size={20} /></div>
          <div><strong>CareSync Hospital</strong><span>Operations workspace</span></div>
          <ChevronRight size={16} />
        </div>
        <div className="nav-caption">WORKSPACE</div>
        <nav className="side-nav">
          {navItems.map(({ name, icon: Icon }) => (
            <button key={name} className={`nav-item ${activeNav === name ? "active" : ""}`} onClick={() => { setActiveNav(name); setMenuOpen(false); setNotice(name === "Overview" ? "" : `${name} is a demo section. Overview metrics are shown here for this starter build.`); }}>
              <Icon size={18} /><span>{name}</span>{name === "AI Insights" && <span className="nav-new">AI</span>}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="support-card"><div className="support-icon"><Activity size={18} /></div><strong>Care coordination</strong><p>Keep your teams aligned with a shared operational picture.</p><button onClick={() => setNotice("CareSync demo support: this prototype uses fictional sample data.")}>Learn more <ChevronRight size={14} /></button></div>
          <button className="nav-item muted" onClick={() => setNotice("Settings are a placeholder in this demo.")}><Settings size={18} /><span>Settings</span></button>
          <button className="nav-item muted" onClick={logout}><LogOut size={18} /><span>Exit demo</span></button>
        </div>
      </aside>
      {menuOpen && <button className="mobile-scrim" aria-label="Close navigation" onClick={() => setMenuOpen(false)} />}
      <section className="main-area">
        <header className="topbar">
          <button className="icon-button mobile-menu" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle menu"><Menu size={20} /></button>
          <div className="breadcrumbs"><span>Workspace</span><ChevronRight size={14} /><strong>{activeNav}</strong></div>
          <div className="top-actions">
            <div className={`api-status ${apiStatus}`}><span />{apiStatus === "online" ? "API connected" : apiStatus === "offline" ? "Demo mode" : "Connecting…"}</div>
            <button className="icon-button" aria-label="Search" onClick={() => setNotice("Search is a placeholder in this starter demo.")}><Search size={18} /></button>
            <button className="icon-button notification-button" aria-label="Notifications" onClick={() => setNotice("You are viewing all demo alerts below.")}><Bell size={18} /><i /></button>
            <div className="profile-chip"><div className="profile-avatar">CS</div><div><strong>{role}</strong><span>Demo session</span></div><button aria-label="Exit demo" onClick={logout}><LogOut size={16} /></button></div>
          </div>
        </header>
        <div className="dashboard-content">
          <div className="welcome-row">
            <div><div className="eyebrow dashboard-eyebrow">FRIDAY, OCTOBER 23, 2026 <span className="live-dot" /></div><h1>Good day. <span>Let's keep care moving.</span></h1><p>A clear view of your hospital operations, all in one place.</p></div>
            <button className="secondary-button" onClick={() => { setOverview(fallbackOverview); setNotice("Demo overview refreshed."); }}><Activity size={16} /> Refresh overview</button>
          </div>
          {notice && <div className="notice-banner"><Sparkles size={17} /><span>{notice}</span><button onClick={() => setNotice("")} aria-label="Dismiss"><X size={16} /></button></div>}
          <div className="demo-banner"><ShieldCheck size={16} /><span><strong>Demo environment</strong> — all figures below are fictional and for demonstration only.</span></div>
          <div className="metric-grid">
            <MetricCard title="Total beds" value={overview.beds.total} detail={`${overview.beds.available} available`} icon={<BedDouble />} tone="blue" trend="Capacity overview" />
            <MetricCard title="Waiting patients" value={overview.waiting_patients} detail="Across demo departments" icon={<Users />} tone="violet" trend="Needs coordination" />
            <MetricCard title="Pending discharges" value={overview.pending_discharges} detail="Awaiting final checks" icon={<ClipboardList />} tone="amber" trend="Review workflow" />
            <MetricCard title="Delayed lab reports" value={overview.delayed_lab_reports} detail="Past target turnaround" icon={<FlaskConical />} tone="rose" trend="Follow-up suggested" />
          </div>
          <div className="content-grid">
            <section className="panel occupancy-panel">
              <div className="panel-heading"><div><span className="panel-kicker">CAPACITY</span><h2>Bed occupancy</h2></div><button className="text-action" onClick={() => setNotice("Bed Management is a placeholder section in this starter build.")}>View details <ChevronRight size={15} /></button></div>
              <div className="occupancy-main"><div><strong>{occupancy}%</strong><span>overall occupancy</span></div><div className="occupancy-ring" style={{ "--progress": `${occupancy}%` } as React.CSSProperties}><div><BedDouble size={23} /><strong>{overview.beds.occupied}</strong><span>occupied</span></div></div></div>
              <div className="progress-track"><div style={{ width: `${occupancy}%` }} /></div>
              <div className="bed-legend">
                <LegendDot tone="blue" label="Occupied" value={overview.beds.occupied} />
                <LegendDot tone="green" label="Available" value={overview.beds.available} />
                <LegendDot tone="amber" label="Blocked" value={overview.beds.blocked} />
              </div>
              <div className="capacity-note"><div className="note-icon"><Activity size={17} /></div><p><strong>Capacity signal</strong><br />There are {overview.beds.available} available beds in this fictional overview. Confirm ward suitability before assigning.</p></div>
            </section>
            <section className="panel staff-panel">
              <div className="panel-heading"><div><span className="panel-kicker">PEOPLE</span><h2>Staff on duty</h2></div><div className="round-icon"><Stethoscope size={19} /></div></div>
              <div className="staff-count"><strong>{overview.staff_on_duty}</strong><span>team members</span><span className="status-pill"><span /> Demo roster</span></div>
              <div className="staff-rows">
                <div className="staff-row"><div className="staff-icon doctor"><Stethoscope size={17} /></div><div><strong>Doctors</strong><span>Demo coverage</span></div><b>12</b></div>
                <div className="staff-row"><div className="staff-icon nurse"><HeartPulse size={17} /></div><div><strong>Nursing team</strong><span>Ward & critical care</span></div><b>20</b></div>
                <div className="staff-row"><div className="staff-icon support"><Users size={17} /></div><div><strong>Support staff</strong><span>Operations & services</span></div><b>6</b></div>
              </div>
              <button className="wide-link" onClick={() => setNotice("Staff & Rosters is a placeholder section in this starter build.")}>Open staff & rosters <ArrowUpRight size={16} /></button>
            </section>
          </div>
          <section className="panel alerts-panel">
            <div className="panel-heading"><div><span className="panel-kicker">ATTENTION NEEDED</span><h2>Operational signals</h2></div><span className="alert-count">{overview.alerts.length} demo alerts</span></div>
            <div className="alerts-list">
              {overview.alerts.map((alert, i) => (
                <article className="alert-row" key={alert.title}>
                  <div className={`alert-priority ${alert.priority.toLowerCase()}`}><span /></div>
                  <div className="alert-copy"><div className="alert-title-line"><h3>{alert.title}</h3><span className={`priority-tag ${alert.priority.toLowerCase()}`}>{alert.priority} priority</span></div><p>{alert.detail}</p></div>
                  <button className="alert-action" onClick={() => setNotice(`Review opened: ${alert.title}. This is a demo-only signal.`)} aria-label={`Review ${alert.title}`}><ChevronRight size={18} /></button>
                </article>
              ))}
            </div>
            <div className="alerts-footer"><Sparkles size={16} /><span>CareSync surfaces possible follow-ups. Staff should verify all information before taking action.</span></div>
          </section>
          <footer className="dashboard-footer"><span>CareSync · Hospital operations workspace</span><span><span className="live-dot" /> Demo mode · No real patient data</span></footer>
        </div>
      </section>
    </main>
  );
}

function Brand() {
  return <div className="brand"><div className="brand-mark"><HeartPulse size={22} strokeWidth={2.2} /></div><div><strong>CareSync</strong><span>CARE, CONNECTED.</span></div></div>;
}

function MetricCard({ title, value, detail, icon, tone, trend }: { title: string; value: number; detail: string; icon: React.ReactNode; tone: string; trend: string }) {
  return <article className="metric-card"><div className="metric-top"><div className={`metric-icon ${tone}`}>{icon}</div><span className="metric-trend"><ArrowDownRight size={13} /> {trend}</span></div><p>{title}</p><div className="metric-value">{value.toLocaleString("en-IN")}</div><div className="metric-detail">{detail}</div></article>;
}

function LegendDot({ tone, label, value }: { tone: string; label: string; value: number }) {
  return <div className="legend-item"><span className={`legend-dot ${tone}`} /><span>{label}</span><strong>{value}</strong></div>;
}
