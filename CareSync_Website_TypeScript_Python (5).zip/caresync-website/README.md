# CareSync — TypeScript frontend + Python backend

A beginner-friendly starter website:
- **Frontend:** React + TypeScript + Vite
- **Backend:** Python + FastAPI
- **Login:** No username/password. Click **Enter CareSync** to open the demo dashboard.
- **Data:** Fictional demo data only; nothing is saved to a database.

## Run it

You need Node.js and Python installed.

### 1) Start the Python backend
Open a terminal in this folder:

```bash
cd backend
python -m venv .venv
```

Activate the environment:
- Windows PowerShell: `.\.venv\Scripts\Activate.ps1`
- Windows Command Prompt: `.\.venv\Scripts\activate.bat`
- macOS/Linux: `source .venv/bin/activate`

Then run:

```bash
pip install -r requirements.txt
uvicorn main:app --reload
```

Backend runs at `http://127.0.0.1:8000`.
API docs: `http://127.0.0.1:8000/docs`

### 2) Start the TypeScript frontend
Open a **second** terminal in the project folder:

```bash
cd frontend
npm install
npm run dev
```

Open the URL Vite prints, usually `http://localhost:5173`.

## Notes
- The login button is intentionally a **demo entry button**, not secure authentication.
- The backend returns sample values for a prototype. Replace the demo data and add real authentication, authorization, and a database before using this for real hospital or patient data.
- The login background uses an external Unsplash image URL and needs an internet connection. If you want to use a locally saved image, put it in `frontend/public/hospital-bg.jpg` and update the CSS background URL.
